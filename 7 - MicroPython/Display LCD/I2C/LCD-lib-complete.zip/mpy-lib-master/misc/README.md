# MISC

* [DS1302 RTC drive](DS1302)
* [DS1307 RTC drive](DS1307)
* [DS3231 RTC drive](DS3231)
* [AT24XX EEPROM drive](AT24XX)
* [UART with rxd irq](irqUART)
* [MCP401x 7-Bit Digital POT](MCP401x)
* [PCF8653 RTC drive](pcf8653)

From microbit/micropython Chinese community.  
www.micropython.org.cn

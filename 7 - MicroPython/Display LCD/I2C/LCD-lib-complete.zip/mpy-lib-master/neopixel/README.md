# Neopixel-libs


* [ESP8266/ESP32 neopixel 16x16 display drive](neo_16x16)
* [ESP8266/ESP32 neopixel 16x16 image display drive](neo_16x16_img)

From microbit/micropython Chinese community.  
www.micropython.org.cn

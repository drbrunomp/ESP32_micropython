# micropython-libs

All kinds of micropython drives, examples, libraries.

* [LCD](lcd)
* [LED](LED)
* [Sensor](sensor)
* [Neopixel](neopixel)
* keyboard
* radio
* bluetooth
* [misc](misc)

From microbit/micropython Chinese community.  
www.micropython.org.cn

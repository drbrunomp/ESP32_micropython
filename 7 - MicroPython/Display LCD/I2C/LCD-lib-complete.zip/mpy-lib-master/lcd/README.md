# LCD-libs


* [I2C LCD1602 drive](I2C_LCD1602)
* [3Wire-HT1621B-GDC03849](3Wire-HT1621B-GDC03849)


From microbit/micropython Chinese community.  
www.micropython.org.cn

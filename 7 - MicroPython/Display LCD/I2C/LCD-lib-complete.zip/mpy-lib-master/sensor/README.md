# Sensor-libs


* [BMP180 Digital pressure sensor drive](bmp180) **(recommend replace with BMP280)**
* [BMP280 Digital pressure sensor drive](bmp280)
* [BME280 humidity and pressure sensor drive](bme280)
* [APDS9930 Digital Proximity and Ambient Light Sensor](APDS9930)
* [ST HTS221 humidity and temperature sensor](HTS221)
* [ST LPS22 pressure sensor](LPS22)
* [ST STTS751 temperature sensor](STTS751)
* [ST LIS2MDL magnetic sensor](LIS2MDL)
* [ST LIS2DW12 motion sensor](LIS2DW12)
* [ST LSM6DSO 3D accelerometer and 3D gyroscope sensor](LSM6DSO)
* [NTC thermistor](NTC)

From microbit/micropython Chinese community.  
www.micropython.org.cn
